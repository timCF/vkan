#!/bin/bash
java -jar vkan-0.1.0-SNAPSHOT-standalone.jar
